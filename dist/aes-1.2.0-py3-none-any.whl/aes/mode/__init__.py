# -*- coding: utf-8 -*-

# from ._mode import ECB, CBC, CTR